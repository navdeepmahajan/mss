var a00004 =
[
    [ "WBCSDKException", "a00004.html#afbfe4e4d653e73fe87c8fdbd77c62a9a", null ],
    [ "WBCSDKException", "a00004.html#ab39cfb8d60b203c3f66c00b64d8d4f5c", null ],
    [ "ErrorCode", "a00004.html#a7165907061c37e62034d67ebe7686e0d", null ]
];