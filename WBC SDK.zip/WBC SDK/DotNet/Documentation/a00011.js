var a00011 =
[
    [ "Vasco", "a00012.html", "a00012" ]
];