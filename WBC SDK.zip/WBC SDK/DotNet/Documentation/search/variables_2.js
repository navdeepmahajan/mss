var searchData=
[
  ['version',['VERSION',['../a00001.html#a56e71553f6adb2a4fa284f5154f4c926',1,'Com::Vasco::Digipass::Sdk::Utils::WBC::WBCSDK']]]
];
