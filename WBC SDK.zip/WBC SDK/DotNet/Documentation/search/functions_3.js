var searchData=
[
  ['wbcsdkexception',['WBCSDKException',['../a00004.html#afbfe4e4d653e73fe87c8fdbd77c62a9a',1,'Com.Vasco.Digipass.Sdk.Utils.WBC.WBCSDKException.WBCSDKException(int errorCode)'],['../a00004.html#ab39cfb8d60b203c3f66c00b64d8d4f5c',1,'Com.Vasco.Digipass.Sdk.Utils.WBC.WBCSDKException.WBCSDKException(int errorCode, Exception cause)']]]
];
