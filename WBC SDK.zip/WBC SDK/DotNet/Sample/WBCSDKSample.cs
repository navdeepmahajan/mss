// (c) 1999 - 2020 OneSpan North America Inc. All rights reserved.


/////////////////////////////////////////////////////////////////////////////
//
//
// This file is example source code. It is provided for your information and
// assistance. See your licence agreement for details and the terms and
// conditions of the licence which governs the use of the source code. By using
// such source code you will be accepting these terms and conditions. If you do
// not wish to accept these terms and conditions, DO NOT OPEN THE FILE OR USE
// THE SOURCE CODE.
//
// Note that there is NO WARRANTY.
//
//////////////////////////////////////////////////////////////////////////////



using System;
#if WINDOWS_UWP
using System.Diagnostics;
#endif

namespace Com.Vasco.Digipass.Sdk.Utils.WBC.Sample
{
    /**
     * Sample application that shows the use of the WBC SDK.
     */
    public class WBCSDKSample
    {
#if WINDOWS_UWP
        public static void Sample()
#else
        public static void Main(String[] args)
#endif
        {
            try
             {
                //Create an initialization vector
                byte[] initializationVector = new byte[] { (byte) 0xA4, (byte) 0x45, (byte) 0x10, (byte) 0xA5, (byte) 0x57,
                        (byte) 0xC4, (byte) 0x74, (byte) 0xB5, (byte) 0xE5, (byte) 0x65, (byte) 0xA7, (byte) 0x74,
                        (byte) 0xF5, (byte) 0xA7, (byte) 0x74, (byte) 0xF5 };

                //Create a new WBCSDKTables object that will access your tables.
                //The WBCSDKTablesImpl file must be generated with the WBCSDKTableGenerator.exe
                WBCSDKTables tables = (WBCSDKTables) new WBCSDKTablesImpl();

                //Create the input that will be encrypted
                byte[] input, encrypted, decrypted;
                String tmpStr = "This is a sample string to test the WBCSDK";
                Console.Write("Input string : " + tmpStr + "\n");

                //Convert the string input into a byte array input
                input = System.Text.Encoding.UTF8.GetBytes(tmpStr);

                //Encrypt with cipher mechanism AES, cipher mode CTR, your table variable, the initialization vector, and your input.
                encrypted = WBCSDK.Encrypt(WBCSDKConstants.CRYPTO_MECHANISM_AES, WBCSDKConstants.CRYPTO_MODE_CTR, (WBCSDKTables)tables,
                        initializationVector, input);
                tmpStr = System.Text.Encoding.UTF8.GetString(encrypted);
                Console.Write("Encrypted string : " + tmpStr + "\n");

                //Decrypt the encrypted data using the same parameters (but the input) 
                decrypted = WBCSDK.Decrypt(WBCSDKConstants.CRYPTO_MECHANISM_AES, WBCSDKConstants.CRYPTO_MODE_CTR, (WBCSDKTables)tables, 
                        initializationVector, encrypted);
                tmpStr = System.Text.Encoding.UTF8.GetString(decrypted);
                Console.Write("Decrypted string : " + tmpStr + "\n");

            }
            catch (WBCSDKException e)
            {
                // Display the exception message, if any.
                Console.Write("A WBCSDKException occurred with error code: " + e.ErrorCode);
            }
        }

#if WINDOWS_UWP
        /**
        * Utils class to mimick Console App 
        */
        class Console
        {

            public class Error
            {
                public static void WriteLine(string message)
                {
                    Debug.WriteLine(message);
                }
            }

            public static void WriteLine(string message)
            {
                Debug.WriteLine(message);
            }

            internal static void Write(string v)
            {
                Debug.Write(v);
            }
        }
#endif
    }
}