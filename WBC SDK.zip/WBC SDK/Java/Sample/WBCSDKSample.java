// (c) 1999 - 2020 OneSpan North America Inc. All rights reserved.


/////////////////////////////////////////////////////////////////////////////
//
//
// This file is example source code. It is provided for your information and
// assistance. See your licence agreement for details and the terms and
// conditions of the licence which governs the use of the source code. By using
// such source code you will be accepting these terms and conditions. If you do
// not wish to accept these terms and conditions, DO NOT OPEN THE FILE OR USE
// THE SOURCE CODE.
//
// Note that there is NO WARRANTY.
//
//////////////////////////////////////////////////////////////////////////////



package com.vasco.digipass.sdk.utils.wbc.sample;

import com.vasco.digipass.sdk.utils.wbc.WBCSDKTablesImpl;
import com.vasco.digipass.sdk.utils.wbc.WBCSDK;
import com.vasco.digipass.sdk.utils.wbc.WBCSDKConstants;
import com.vasco.digipass.sdk.utils.wbc.WBCSDKException;
import com.vasco.digipass.sdk.utils.wbc.WBCSDKTables;

/**
 * Sample application that shows the use of the WBC SDK.
 * It needs whitebox tables (generated with the tableGeneratorSDK), 
 * the WBCSDK library, and the UtilitiesSDK library.
 */
public class WBCSDKSample
{

    public static void main(String[] args)
    {
        try
        {
            //Create an initialization vector
            final byte[] initializationVector = { (byte) 0xA4, (byte) 0x45, (byte) 0x10, (byte) 0xA5, (byte) 0x57,
                    (byte) 0xC4, (byte) 0x74, (byte) 0xB5, (byte) 0xE5, (byte) 0x65, (byte) 0xA7, (byte) 0x74,
                    (byte) 0xF5, (byte) 0xA7, (byte) 0x74, (byte) 0xF5 };

            //Create a new WBCSDKTables object that will access your tables.
            //The WBCSDKTablesImpl file must be generated with the WBCSDKTableGenerator.exe
            WBCSDKTables tables = (WBCSDKTables) new WBCSDKTablesImpl();

            //Create the input that will be encrypted
            byte[] input, encrypted, decrypted;
            String tmpStr = "This is a sample string to test the WBCSDK";
            System.out.println("Input string : " + tmpStr);

            //Convert the string input into a byte array input
            input = tmpStr.getBytes();

            //Encrypt with cipher mechanism 1, cipher mode 2, your table variable, the initialization vector, and your input.
            encrypted = WBCSDK.encrypt(WBCSDKConstants.CRYPTO_MECHANISM_AES, WBCSDKConstants.CRYPTO_MODE_CTR,
                    (WBCSDKTables) tables, initializationVector, input);
            tmpStr = new String(encrypted, "UTF-8");
            System.out.println("Encrypted string : " + tmpStr);

            //Decrypt the encrypted data using the same parameters (but the input) 
            decrypted = WBCSDK.decrypt(WBCSDKConstants.CRYPTO_MECHANISM_AES, WBCSDKConstants.CRYPTO_MODE_CTR,
                    (WBCSDKTables) tables, initializationVector, encrypted);
            tmpStr = new String(decrypted, "UTF-8");
            System.out.println("Decrypted string : " + tmpStr);

        }
        catch (WBCSDKException e)
        {
            // Display the exception message, if any.
            System.out.println("A WBCSDKException occurred with error code: " + e.getErrorCode());
        }
        catch (Exception e)
        {
            // Unexpected error, should never happened.
            e.printStackTrace();
        }
    }
}
