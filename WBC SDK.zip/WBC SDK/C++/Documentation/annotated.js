var annotated =
[
    [ "com", null, [
      [ "vasco", null, [
        [ "digipass", null, [
          [ "sdk", null, [
            [ "utils", null, [
              [ "wbc", null, [
                [ "WBCSDK", "a00003.html", "a00003" ],
                [ "WBCSDKConstants", "a00004.html", "a00004" ],
                [ "WBCSDKErrorCodes", "a00005.html", "a00005" ],
                [ "WBCSDKException", "a00006.html", "a00006" ],
                [ "WBCSDKTables", "a00007.html", "a00007" ]
              ] ]
            ] ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "mzd_block_t", "a00001.html", null ],
    [ "mzd_t", "a00002.html", null ]
];