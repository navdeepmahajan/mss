var searchData=
[
  ['wbcsdkexception',['WBCSDKException',['../a00006.html#afbfe4e4d653e73fe87c8fdbd77c62a9a',1,'com::vasco::digipass::sdk::utils::wbc::WBCSDKException::WBCSDKException(int errorCode)'],['../a00006.html#aa8223f7af678fa25fea11bd977420231',1,'com::vasco::digipass::sdk::utils::wbc::WBCSDKException::WBCSDKException(int errorCode, exception cause)']]]
];
