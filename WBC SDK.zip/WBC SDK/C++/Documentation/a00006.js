var a00006 =
[
    [ "WBCSDKException", "a00006.html#afbfe4e4d653e73fe87c8fdbd77c62a9a", null ],
    [ "WBCSDKException", "a00006.html#aa8223f7af678fa25fea11bd977420231", null ],
    [ "~WBCSDKException", "a00006.html#a8c620a76937ca4f962382a792436dcd4", null ],
    [ "getCause", "a00006.html#a4705a159e58ec6fd4e689378b1f8cd3b", null ],
    [ "getErrorCode", "a00006.html#a81996e8ca7b3e049c077c447b8830434", null ]
];