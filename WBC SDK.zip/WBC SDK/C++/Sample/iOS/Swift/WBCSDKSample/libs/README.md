Copy here :
    - "WBCSDK.framework" from the related sample folder "/WBC SDK/C++/Bin/iOS"
    - "libUtilitiesSDK.a" from the related sample folder "/Utilities SDK/C/iOS"
    - "fipsOpenSSL.framework" from the related sample folder "/Utilities SDK/C/iOS"
