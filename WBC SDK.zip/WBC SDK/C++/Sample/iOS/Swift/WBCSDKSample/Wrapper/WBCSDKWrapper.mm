// (c) 1999 - 2020 OneSpan North America Inc. All rights reserved.


/////////////////////////////////////////////////////////////////////////////
//
//
// This file is example source code. It is provided for your information and
// assistance. See your licence agreement for details and the terms and
// conditions of the licence which governs the use of the source code. By using
// such source code you will be accepting these terms and conditions. If you do
// not wish to accept these terms and conditions, DO NOT OPEN THE FILE OR USE
// THE SOURCE CODE.
//
// Note that there is NO WARRANTY.
//
//////////////////////////////////////////////////////////////////////////////



#import "WBCSDKWrapper.h"
#import "WBCSDKTablesImpl.h"
#import <WBCSDK/WBCSDK.h>
#import <WBCSDK/WBCSDKException.h>
#import <WBCSDK/WBCSDKConstants.h>

using namespace com::vasco::digipass::sdk::utils::wbc;

static NSString *const kDomain = @"WBCSDK";

NSString *const WBCSDK_VERSION = [NSString stringWithUTF8String:VERSION.c_str()];

@implementation WBCSDKWrapper

+ (NSData *)encrypt:(const unsigned char)mechanism mode:(const unsigned char)mode initialVector:(NSArray<NSNumber *>*)initialVector dataIn:(NSData *)dataIn error:(NSError **)error {
    try {
        //Create a new WBCSDKTables object that will access your tables.
        //The WBCSDKTablesImpl file must be generated with the WBCSDKTableGenerator.exe
        WBCSDKTablesImpl wbcTables;
        
        // create and format input and output data
        long int inputLength = dataIn.length;
        long int encryptedLength = inputLength;
        unsigned char* input = (unsigned char*) [dataIn bytes];
        
        //We add 1 to the length to account for the end of string character
        unsigned char encrypted[encryptedLength + 1];
        
        //Convert the string input into a byte array input
        memset(encrypted, 0, encryptedLength + 1);
        
        //Convert NSArray to unsigned char*
        long int ivLength = [initialVector count];
        unsigned char iv[ivLength];
        memset(iv, 0, ivLength + 1);
        for (int i = 0; i<ivLength; i++) {
            iv[i] = [initialVector[i] unsignedCharValue];
        }
        
        WBCSDK::encrypt(mechanism, mode, &wbcTables, iv, ivLength, input, inputLength, encrypted, &encryptedLength);
        
        NSData* data = [NSData dataWithBytes:(const void *)encrypted length:encryptedLength];
        
        return data;
    }
    catch (WBCSDKException &e) {
        *error = [[NSError alloc] initWithDomain:kDomain code:e.getErrorCode() userInfo:nil];
        return nil;
    }
}

+ (NSData *)decrypt:(const unsigned char)mechanism mode:(const unsigned char)mode initialVector:(NSArray<NSNumber *>*)initialVector dataIn:(NSData *)dataIn error:(NSError **)error {
    try {
        //Create a new WBCSDKTables object that will access your tables.
        //The WBCSDKTablesImpl file must be generated with the WBCSDKTableGenerator.exe
        WBCSDKTablesImpl wbcTables;
        
        // create and format input and output data
        long int inputLength = dataIn.length;
        long int decryptedLength = inputLength;
        unsigned char* input = (unsigned char*) [dataIn bytes];
        
        //We add 1 to the length to account for the end of string character
        unsigned char decrypted[decryptedLength + 1];
        
        //Convert the string input into a byte array input
        memset(decrypted, 0, decryptedLength + 1);
        
        //Convert NSArray to unsigned char*
        long int ivLength = [initialVector count];
        unsigned char iv[ivLength];
        memset(iv, 0, ivLength + 1);
        for (int i = 0; i<ivLength; i++) {
            iv[i] = [initialVector[i] unsignedCharValue];
        }
        
        WBCSDK::encrypt(mechanism, mode, &wbcTables, iv, ivLength, input, inputLength, decrypted, &decryptedLength);
        
        NSData* data = [NSData dataWithBytes:(const void *)decrypted length:decryptedLength];
        
        return data;
    }
    catch (WBCSDKException &e) {
        *error = [[NSError alloc] initWithDomain:kDomain code:e.getErrorCode() userInfo:nil];
        return nil;
    }
}

@end
