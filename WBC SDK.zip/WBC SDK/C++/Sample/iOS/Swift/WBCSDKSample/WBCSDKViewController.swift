// (c) 1999 - 2020 OneSpan North America Inc. All rights reserved.


/////////////////////////////////////////////////////////////////////////////
//
//
// This file is example source code. It is provided for your information and
// assistance. See your licence agreement for details and the terms and
// conditions of the licence which governs the use of the source code. By using
// such source code you will be accepting these terms and conditions. If you do
// not wish to accept these terms and conditions, DO NOT OPEN THE FILE OR USE
// THE SOURCE CODE.
//
// Note that there is NO WARRANTY.
//
//////////////////////////////////////////////////////////////////////////////



import UIKit

class WBCSDKViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Create the input that will be encrypted
        let inputStr = "This is a sample string to test the WBCSDK"
        print("Input string :", inputStr)
        let inputData: Data = inputStr.data(using: .ascii)!
        
        //Create an initialization vector
        let initializationVector: [NSNumber] = [0xA4, 0x45, 0x10, 0xA5, 0x57, 0xC4, 0x74, 0xB5, 0xE5, 0x65, 0xA7, 0x74, 0xF5, 0xA7, 0x74, 0xF5]
        
        do {
            //Encrypt with cipher mechanism AES, cipher mode CTR, the initialization vector, and your input.
            let encryptedData = try WBCSDKWrapper.encrypt(CRYPTO_MECHANISM_AES, mode: CRYPTO_MODE_CTR, initialVector: initializationVector, dataIn: inputData)
            
            let encryptedStr = String(data: encryptedData, encoding: .ascii)
            print("Encrypted string : " + encryptedStr!)
            
            //Decrypt the encrypted data using the same parameters (but the input)
            let decryptedData = try WBCSDKWrapper.decrypt(CRYPTO_MECHANISM_AES, mode: CRYPTO_MODE_CTR, initialVector: initializationVector, dataIn: encryptedData)
            
            let decryptedStr = String(data: decryptedData, encoding: .ascii)
            print("Decrypted string : " + decryptedStr!)
        }
        catch let error as NSError {
            print("A WBCSDKException occurred with error code:", error.code)
        }
        
    }


}

