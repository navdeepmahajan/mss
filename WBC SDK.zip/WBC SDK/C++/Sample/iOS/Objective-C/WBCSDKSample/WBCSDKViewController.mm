// (c) 1999 - 2020 OneSpan North America Inc. All rights reserved.


/////////////////////////////////////////////////////////////////////////////
//
//
// This file is example source code. It is provided for your information and
// assistance. See your licence agreement for details and the terms and
// conditions of the licence which governs the use of the source code. By using
// such source code you will be accepting these terms and conditions. If you do
// not wish to accept these terms and conditions, DO NOT OPEN THE FILE OR USE
// THE SOURCE CODE.
//
// Note that there is NO WARRANTY.
//
//////////////////////////////////////////////////////////////////////////////



#import "WBCSDKViewController.h"
#import "WBCSDKTablesImpl.h"
#import <WBCSDK/WBCSDK.h>
#import <WBCSDK/WBCSDKConstants.h>
#import <WBCSDK/WBCSDKException.h>

using namespace com::vasco::digipass::sdk::utils::wbc;

@implementation WBCSDKViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    try
    {
        //Create a new WBCSDKTables object that will access your tables.
        //The WBCSDKTablesImpl file must be generated with the WBCSDKTableGenerator.exe
        WBCSDKTablesImpl tables;
        
        //Create the input that will be encrypted
        NSString *tmpStr = @"This is a sample string to test the WBCSDK";
        
        NSLog(@"Input string : %@", tmpStr);
        
        // create and format input and output datas
        long int inputLength = tmpStr.length;
        long int encryptedLength = inputLength;
        long int decryptedLength = inputLength;
        
        unsigned char input[inputLength];
        //We add 1 to the length to account for the end of string character
        unsigned char encrypted[encryptedLength + 1];
        unsigned char decrypted[decryptedLength + 1];
        
        //Convert the string input into a byte array input
        memcpy(input, [tmpStr cStringUsingEncoding:NSASCIIStringEncoding], inputLength);
        memset(encrypted, 0, encryptedLength + 1);
        memset(decrypted, 0, decryptedLength + 1);
        
        //Create an initialization vector
        unsigned char initializationVector[16] =
        { 0xA4, 0x45, 0x10, 0xA5, 0x57, 0xC4, 0x74, 0xB5, 0xE5, 0x65, 0xA7, 0x74, 0xF5, 0xA7, 0x74, 0xF5 };
        
        
        //Encrypt with cipher mechanism AES, cipher mode CTR, your table variable, the initialization vector, and your input.
        WBCSDK::encrypt(WBCSDKConstants::CRYPTO_MECHANISM_AES, WBCSDKConstants::CRYPTO_MODE_CTR, &tables,
                        initializationVector, 16, input, inputLength, encrypted, &encryptedLength);
        NSLog(@"Encrypted string : %s", encrypted);
        
        //Decrypt the encrypted data using the same parameters (but the input)
        WBCSDK::decrypt(WBCSDKConstants::CRYPTO_MECHANISM_AES, WBCSDKConstants::CRYPTO_MODE_CTR, &tables,
                        initializationVector, 16, encrypted, encryptedLength, decrypted, &decryptedLength);
        
        NSLog(@"Decrypted string : %s", decrypted);
        
    }
    catch (WBCSDKException &e)
    {
        // Display the exception message, if any.
        NSLog(@"A WBCSDKException occurred with error code: %i", e.getErrorCode());
    }
    catch (exception &e)
    {
        // Unexpected error, should never happened.
        NSLog(@"%s", e.what());
    }
}


@end
