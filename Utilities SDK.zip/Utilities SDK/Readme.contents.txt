===============================================================
PACKAGE DESCRIPTION For Utilities SDK
===============================================================
The package contains 4 top-level directories:
=============================================
  Android
=============================================
	Contains Utilities.aar 
=============================================
  C
=============================================
The Bin directory includes libraries for different platform/OS:
- [Android]: contains Utilities SDK - C static library for Android OS 1.5 and Higher
	- [arm64-v8a]: contains Utilities SDK - C for ARMv8.
		       contains libopenSSL.so 
	- [armeabi-v7a]: contains Utilities SDK - C for ARMv7.
		         contains libopenSSL.so 
	- [x86]: contains Utilities SDK - C for X86.
		 contains libopenSSL.so 
	- [x86_64]: contains Utilities SDK - C for X86_64.
		    contains libopenSSL.so 
- [iOS]: contains Utilities SDK - C framework ARM for iPhone 7.0 
	 contains fipOpenSSL.framework
	
- [Linux_32]: 
	- [Static]:  contains Utilities SDK - C static library for linux 32-bit.
- [Linux_64]: 
	- [Static]:  contains Utilities SDK - C static library for linux 64-bit.
- [Mac_OS_X]: 
	- [Static]:  contains Utilities SDK - C static framework for Mac OSX (32/64-bit).
- [Windows_64]: 
	- [Static]: contains Utilities SDK - C static library for Windows 64-bit.
		- [MD] : using multithread, dynamic version of the run-time library
		- [MT] : using multithread, static version of the run-time library

=============================================
  .NET
=============================================
The Library folder contains the Utilities SDK - .NET dll file.
This is the .NET library to integrate.
It provides functions for Activation, OTP generation and Signature calculation.
The GUI and the Data Storage are part of the integration process.
The Bin directory includes two different libraries:
- [4.0]: library for .Net framework 4.0
- [UWP]: library for Universal Windows Platform

=============================================
  Java
=============================================
The Library folder contains the Utilities SDK - Java .JAR file.
This is the Java library to integrate.
It provides functions for Activation, OTP generation and Signature calculation.
The GUI and the Data Storage are part of the integration process.

=============================================
Demo DPX
=============================================
This folder contains demo DPX files for integration testing in multi-device and standard activation mode.